import React, { useState, useEffect } from 'react';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';
import { fetchTasks, saveTask } from './services/taskService';
import './App.css';

const App = () => {
  const [tasks, setTasks] = useState([]);
  const [taskToEdit, setTaskToEdit] = useState(null);

  useEffect(() => {
    setTasks(fetchTasks());
  }, []);

  const addTask = (task) => {
    const newTasks = [...tasks, { title: task }];
    setTasks(newTasks);
    saveTask(newTasks);
  };

  const editTask = (task) => {
    const updatedTasks = tasks.map((t, index) =>
      index === taskToEdit.index ? { ...t, title: task } : t
    );
    setTasks(updatedTasks);
    saveTask(updatedTasks);
    setTaskToEdit(null);
  };

  const deleteTask = (index) => {
    const newTasks = tasks.filter((_, i) => i !== index);
    setTasks(newTasks);
    saveTask(newTasks);
  };

  const startEditTask = (index) => {
    setTaskToEdit({ index, title: tasks[index].title });
  };

  return (
    <div className="app">
      <h1>To-Do List</h1>
      <TaskForm addTask={addTask} editTask={editTask} taskToEdit={taskToEdit} />
      <TaskList tasks={tasks} editTask={startEditTask} deleteTask={deleteTask} />
    </div>
  );
};

export default App;
