import React from 'react';
import './TaskList.css';

const TaskList = ({ tasks, editTask, deleteTask }) => {
  return (
    <div className="task-list">
      <ul>
        {tasks.map((task, index) => (
          <li key={index}>
            <span>{task.title}</span>
            <button onClick={() => editTask(index)}>Edit</button>
            <button onClick={() => deleteTask(index)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TaskList;
