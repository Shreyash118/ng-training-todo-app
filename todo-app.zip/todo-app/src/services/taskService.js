export const fetchTasks = () => {
    const tasks = localStorage.getItem('tasks');
    return tasks ? JSON.parse(tasks) : [];
  };
  
  export const saveTask = (tasks) => {
    localStorage.setItem('tasks', JSON.stringify(tasks));
  };
  